<?php


// Start class
class WTHEME {

	public $homeURL;
	public $assetsURL;
	public $libraryURL;
	public $wpversion;


	public function __construct() {
			$this->homeURL = home_url();
			$this->assetsURL = get_stylesheet_directory_uri() . '/assets';
			$this->libraryURL = get_stylesheet_directory_uri() . '/library';
			$this->themeversion = wp_get_theme()->get('Version')/*.microtime()*/;
	}

	// enqueue CSS and JS
	public function enqueCSSJS() {
			// CSS Library
			wp_enqueue_style('wtheme-bootstrap-css', $this->libraryURL.'/bootstrap-5.3.3/css/bootstrap.min.css', array(), '1.0', 'all');
			wp_enqueue_style('wtheme-custom-scroll-css', $this->libraryURL.'/custom-scroll/css/custom-scroll.css', array(), '1.0', 'all');
			wp_enqueue_style('wtheme-owl-main-css', $this->libraryURL.'/OwlCarousel-2-2.3.4/css/owl.carousel.min.css', array(), '1.0', 'all');
			wp_enqueue_style('wtheme-owl-theme-css', $this->libraryURL.'/OwlCarousel-2-2.3.4/css/owl.theme.default.min.css', array(), '1.0', 'all');

			// CSS Assets
			wp_enqueue_style('wtheme-font-css', $this->assetsURL.'/css/font.css', array(), $this->themeversion, 'all');
			wp_enqueue_style('wtheme-style-css', get_stylesheet_uri(), array(), $this->themeversion, 'all');

			// JS Library
			wp_enqueue_script( 'wtheme-jquery-script', $this->libraryURL.'/jquery-3.7.1/js/jquery.min.js', array(), '1.0', true );
			wp_enqueue_script( 'wtheme-bootstrap-script', $this->libraryURL.'/bootstrap-5.3.3/js/bootstrap.bundle.min.js', array(), '1.0', true );
			wp_enqueue_script( 'wtheme-custom-scroll-script', $this->libraryURL.'/custom-scroll/js/custom-scroll.js', array(), '1.0', true );			
			wp_enqueue_script( 'wtheme-owl-script', $this->libraryURL.'/OwlCarousel-2-2.3.4/js/owl.carousel.js', array(), '1.0', true );
			
			// JS Assets
			wp_enqueue_script( 'wtheme-main-script', $this->assetsURL.'/js/script.js', array(), $this->themeversion, true );
	}

	// register menu
	public function registerMenus(){
		register_nav_menus(
				array(
						'wtheme_header_menu' => 'Header Menu',
						'wtheme_footer_menu' => 'Footer Menu'
				)
		);
	}

	// 


}
$wtheme_instance = new WTHEME();
// End class




// Hook the static method to 'wp_enqueue_scripts'
add_action('wp_enqueue_scripts', [$wtheme_instance, 'enqueCSSJS']);

// Register Menu
$wtheme_instance->registerMenus();



